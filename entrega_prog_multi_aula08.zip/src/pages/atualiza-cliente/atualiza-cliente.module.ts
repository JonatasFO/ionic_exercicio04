import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AtualizaClientePage } from './atualiza-cliente';

@NgModule({
  declarations: [
    AtualizaClientePage,
  ],
  imports: [
    IonicPageModule.forChild(AtualizaClientePage),
  ],
})
export class AtualizaClientePageModule {}
